<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold text-gray-800">Socios Activos</h2>
     <?php $__env->endSlot(); ?>

    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <div class="flex justify-between mb-4">
                <!-- Formulario de búsqueda -->
                <form method="GET" action="<?php echo e(route('socios.activos')); ?>" class="flex space-x-2">
                    <input type="text" name="search" placeholder="Buscar por nombre o apellido"
                        class="border rounded-lg px-3 py-2 w-full sm:w-64"
                        value="<?php echo e(request('search')); ?>">
                    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg">Buscar</button>
                </form>
            </div>

            <!-- Tabla de Socios Activos -->
            <div class="overflow-x-auto">
                <table class="w-full border-collapse border border-gray-300">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="border border-gray-300 px-4 py-2">ID</th>
                            <th class="border border-gray-300 px-4 py-2">Nombre</th>
                            <th class="border border-gray-300 px-4 py-2">Apellido Paterno</th>
                            <th class="border border-gray-300 px-4 py-2">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $socios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border border-gray-300">
                                <td class="border border-gray-300 px-4 py-2"><?php echo e($socio->id); ?></td>
                                <td class="border border-gray-300 px-4 py-2"><?php echo e($socio->nombre); ?></td>
                                <td class="border border-gray-300 px-4 py-2"><?php echo e($socio->apellido_paterno); ?></td>
                                <td class="border border-gray-300 px-4 py-2">
                                    <a href="<?php echo e(route('adelantos.create', $socio->id)); ?>"
                                        class="bg-green-500 text-white px-4 py-2 rounded-lg">Solicitar</a>
                                    <a href="<?php echo e(route('adelantos.create', $socio->id)); ?>"
                                        class="bg-green-500 text-white px-4 py-2 rounded-lg">Estado Cuenta</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación -->
            <div class="mt-4">
                <?php echo e($socios->links()); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-ahorro\resources\views/socios/activos.blade.php ENDPATH**/ ?>