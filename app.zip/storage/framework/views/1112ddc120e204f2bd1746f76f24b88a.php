<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold text-gray-800">Lista de Préstamos</h2>
     <?php $__env->endSlot(); ?>

    <div class="max-w-6xl mx-auto py-6">
        <div class="mb-4">
            <a href="<?php echo e(route('prestamos.socios')); ?>" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
                ← Volver a Prestamos
            </a>
        </div>

        <table class="w-full bg-white shadow-lg rounded-lg">
            <thead class="bg-gray-200">
                <tr>
                    <th class="px-4 py-2">Socio</th>
                    <th class="px-4 py-2">Monto</th>
                    <th class="px-4 py-2">Saldo Pendiente</th>
                    <th class="px-4 py-2">Estado</th>
                    <th class="px-4 py-2">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?php echo e($prestamo->socio->nombre); ?> <?php echo e($prestamo->socio->apellido_paterno); ?></td>
                        <td class="px-4 py-2 text-green-600 font-bold">$ <?php echo e(number_format($prestamo->monto, 2)); ?></td>
                        <td class="px-4 py-2 text-red-600">$ <?php echo e(number_format($prestamo->saldo_pendiente, 2)); ?></td>
                        <td class="px-4 py-2"><?php echo e($prestamo->estado); ?></td>
                        <td class="px-4 py-2">
                            <a href="<?php echo e(route('prestamos.show', $prestamo->id)); ?>" class="text-blue-600">Ver</a> |
                            <a href="<?php echo e(route('prestamos.edit', $prestamo->id)); ?>" class="text-yellow-600">Editar</a> |
                            <form action="<?php echo e(route('prestamos.destroy', $prestamo->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600" onclick="return confirm('¿Seguro que deseas eliminar este préstamo?');">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php if($prestamos->isEmpty()): ?>
            <p class="text-center text-gray-500 mt-4">No hay préstamos registrados.</p>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-ahorro\resources\views/prestamos/index.blade.php ENDPATH**/ ?>