<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold text-gray-800">Gestión de Préstamos</h2>
     <?php $__env->endSlot(); ?>

    <div class="max-w-6xl mx-auto py-6">
        <div class="mb-4 flex justify-between">
            <a href="<?php echo e(route('dashboard')); ?>" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
                ← Volver al Inicio
            </a>
            <div>
                <input type="text" id="search" placeholder="Buscar por Nombre o Apellido" 
                       class="px-4 py-2 border rounded-lg w-80" onkeyup="filterTable()">
            </div>
        </div>

        <table class="w-full bg-white shadow-lg rounded-lg">
            <thead class="bg-gray-200">
                <tr>
                    <th class="px-4 py-2">Nombre</th>
                    <th class="px-4 py-2">Apellido Paterno</th>
                    <th class="px-4 py-2">Acciones</th>
                </tr>
            </thead>
            <tbody id="sociosTable">
                <?php $__currentLoopData = $socios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?php echo e($socio->nombre); ?></td>
                        <td class="px-4 py-2"><?php echo e($socio->apellido_paterno); ?></td>
                        <td class="px-4 py-2 flex space-x-2">
                            <a href="<?php echo e(route('prestamos.create', $socio->id)); ?>" class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600">
                                Registro
                            </a>
                            <a href="<?php echo e(route('prestamos.edit', $socio->id)); ?>" class="px-3 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600">
                                Modifica
                            </a>
                            <a href="<?php echo e(route('prestamos.show', $socio->id)); ?>" class="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600">
                                Consulta
                            </a>
                            
                            <?php if($socio->prestamos->isNotEmpty()): ?>
                                <a href="<?php echo e(route('abonos.create', ['prestamo' => $socio->prestamos->first()->id])); ?>" 
                                class="px-3 py-1 bg-purple-500 text-white rounded hover:bg-purple-600">
                                    Abonar
                                </a>
                            <?php endif; ?>
                            
                            <a href="<?php echo e(route('estado-cuenta.show', $socio->id)); ?>" class="px-3 py-1 bg-gray-700 text-white rounded hover:bg-gray-800">
                                Estado Cuenta
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php if($socios->isEmpty()): ?>
            <p class="text-center text-gray-500 mt-4">No hay socios registrados.</p>
        <?php endif; ?>
    </div>

    <script>
        function filterTable() {
            let input = document.getElementById("search").value.toLowerCase();
            let rows = document.querySelectorAll("#sociosTable tr");

            rows.forEach(row => {
                let nombre = row.cells[0].textContent.toLowerCase();
                let apellido = row.cells[1].textContent.toLowerCase();
                if (nombre.includes(input) || apellido.includes(input)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-ahorro\resources\views/prestamos/socios.blade.php ENDPATH**/ ?>