<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold text-gray-800">Lista de Socios</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6 max-w-6xl mx-auto">
        <div class="mb-4">
            <a href="<?php echo e(route('socios.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">
                Agregar Socio
            </a>
        </div>
    </div>
    <div class="flex max-w-6xl mx-auto">
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <table class="min-w-full border border-gray-300">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="border px-4 py-2">#</th>
                        <th class="border px-4 py-2">Nombre</th>
                        <th class="border px-4 py-2">Apellido Paterno</th>
                        <th class="border px-4 py-2">Apellido Materno</th>
                        <th class="border px-4 py-2">Ahorro Total</th>
                        <th class="border px-4 py-2">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $socios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="border px-4 py-2"><?php echo e($loop->iteration); ?></td>
                            <td class="border px-4 py-2"><?php echo e($socio->nombre); ?></td>
                            <td class="border px-4 py-2"><?php echo e($socio->apellido_paterno); ?></td>
                            <td class="border px-4 py-2"><?php echo e($socio->apellido_materno); ?></td>
                            <td class="border px-4 py-2">$ <?php echo e(number_format($socio->saldo_ahorro, 2)); ?></td>
                            <td class="border px-4 py-2 flex space-x-2">
                                <a href="<?php echo e(route('socios.show', $socio)); ?>" class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-green-700">Ver</a>
                                <a href="<?php echo e(route('socios.edit', $socio)); ?>" class="px-3 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600">Editar</a>
                                <a href="<?php echo e(route('aportaciones.socio', $socio->id)); ?>" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Aportaciones</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php if($socios->isEmpty()): ?>
                <p class="text-center text-gray-500 mt-4">No hay socios registrados.</p>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-ahorro\resources\views/socios/index.blade.php ENDPATH**/ ?>