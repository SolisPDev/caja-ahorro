<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold text-gray-800"><?php echo e(__('Panel de Control')); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6 px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <!-- Saldo total de ahorro de todos los socios -->
            <div class="p-6 bg-white shadow-lg rounded-lg text-center">
                <h3 class="text-lg font-bold text-gray-700">Saldo Total en Ahorro</h3>
                <p class="text-3xl font-semibold text-green-600 mt-2">$ <?php echo e(number_format($saldoTotalAhorro, 2)); ?></p>
            </div>

            <!-- Préstamos activos (agrega la lógica cuando la tengas) -->
            <div class="p-6 bg-white shadow-lg rounded-lg text-center">
                <h3 class="text-lg font-bold text-gray-700">Préstamos Activos</h3>
                <p class="text-3xl font-semibold text-blue-600 mt-2"><?php echo e($prestamosNoPagados); ?></p>
            </div>

            <!-- Total de Socios Activos (agrega la lógica cuando la tengas) -->
            <div class="p-6 bg-white shadow-lg rounded-lg text-center">
                <h3 class="text-lg font-bold text-gray-700">Socios Activos</h3>
                <p class="text-3xl font-semibold text-blue-600 mt-2"><?php echo e(number_format($sociosActivos, 0)); ?></p> <!-- Sustituye con la cantidad real -->
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-ahorro\resources\views/dashboard.blade.php ENDPATH**/ ?>